### Lab assignment 2

This is the repository for the code of the second lab assignment. You can find the instructions for the lab assignment in both Croatian and English in their folder [here](instructions/).

![The labyrinth!](https://github.com/mttk/AIclass/blob/master/lab2/im/pacard.png)
